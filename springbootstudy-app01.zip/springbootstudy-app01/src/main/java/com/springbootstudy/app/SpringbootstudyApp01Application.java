package com.springbootstudy.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootstudyApp01Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootstudyApp01Application.class, args);
	}

}
